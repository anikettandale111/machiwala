
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center h-100 align-items-center">
    <div class="col-md-5">
        <div class="form-input-content text-center error-page">
            <h1 class="error-text fw-bold">419</h1>
            <h4><i class="fa fa-times-circle text-danger"></i> Expired Error</h4>
            <p>The page you requested was not found.</p> 
            <div>
                <a class="btn btn-primary" href="<?php echo e(route('home')); ?>">Back to Home</a>
            </div>	
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\php8\xampp\htdocs\machiwala\resources\views/errors/419.blade.php ENDPATH**/ ?>